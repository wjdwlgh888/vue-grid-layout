import Vue from 'vue';

module.exports = new Vue();